<?php 
$tmp=false;
foreach($unsur as $i=>$data){
    if($data->no == $nomor){
        $tmp=$data;
        break;
    }
}

?>
<?php if($tmp): ?>
<div class="unsur">
                     <div class="nomor"><?php echo e($tmp->no); ?></div>
                     <div class="simbol"><?php echo e($tmp->code); ?></div>
                     <div class="nama"><?php echo e($tmp->nama); ?></div>
                     <div class="popup hide">
                        <div class="c-row">
                            <div class="col-nomor">
                                <div class="nomor"><?php echo e($tmp->no); ?></div>
                            </div>
                            <div class="col-atomic text-right">
                                <div class="atomic"><?php echo e($tmp->atomic_mass); ?></div>
                            </div>
                          
                        </div>
                        <div class="simbol"><?php echo e($tmp->code); ?></div>
                        <div class="nama"><?php echo e($tmp->nama); ?></div>
                        <input type="hidden" value="<?php echo e($tmp->namajenis); ?>" id="inpJNS">
                        <div class="hidden dsc"><?php echo e($tmp->deskripsi); ?> </div>
                        <div class="hidden mtp"><?php echo e($tmp->melting_point); ?> </div>
                        <div class="hidden btp"><?php echo e($tmp->boiling_point); ?> </div>
                     </div>
</div>
<?php endif; ?><?php /**PATH D:\laragon\www\periodic\resources\views/parts/unsur.blade.php ENDPATH**/ ?>