<?php 
$tmp=false;
foreach($unsur as $i=>$data){
    if($data->no == $nomor){
        $tmp=$data;
        break;
    }
}
?>
<?php if($tmp): ?>
<div class="unsur">
                     <div class="nomor"><?php echo e($tmp->no); ?></div>
                     <div class="simbol"><?php echo e($tmp->code); ?></div>
                     <div class="nama"><?php echo e($tmp->nama); ?></div>
</div>
<?php endif; ?><?php /**PATH D:\laragon\www\periodic\resources\views/parts/unsur.blade.php ENDPATH**/ ?>