<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Tugas Periodik')); ?></title>
   

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/warna.css').'?v='.Config('app.ver')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/warnaperiodik.css').'?v='.Config('app.ver')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('font/style.css').'?v='.Config('app.ver')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/tes.css').'?v='.Config('app.ver')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/tablet.css').'?v='.Config('app.ver')); ?>" media="screen and (max-width: 1000px)">
    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <?php echo $__env->yieldContent('js'); ?>
    <script>
        $(document).ready(function(){   
            $(document).on('click','.play',function(e){
                let cr = $(this).find('.icm').hasClass('icon-play');
                if(cr==true){
                    $(this).find('.icm').removeClass('icon-play').addClass('icon-pause');
                    document.getElementById("pageSound").play();
                }else{
                    $(this).find('.icm').removeClass('icon-pause').addClass('icon-play');
                    document.getElementById("pageSound").pause();
                }
            });

            var MDLP = $("#mdlProfileCenter").modal({show:false});
            $(document).on("click",".icn.about",function(){
                MDLP.modal('show');
            });
        })
    </script>
</head>
<body>
    <div id="app">
        <?php echo $__env->make('parts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="bingkai">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
    <audio id="pageSound" loop>
        <source src="<?php echo e(asset('musik.mp3')); ?>" type="audio/mpeg">
    </audio>
    <?php echo $__env->make('parts.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH D:\laragon\www\periodic\resources\views/layouts/app.blade.php ENDPATH**/ ?>