

<?php $__env->startSection('content'); ?>
<div class="kotak">
<div class="col-md-12">
    <h3>Media</h3>
    <div class="box">
        <div class="kol1">
            <div class="baris">
               <div class="kotakunsur <?php echo e(Obj::warna(1,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>1,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
               <div class="kotakunsur"></div>
               <div class="kotakunsur"></div>
            </div>
            <div class="baris">
               <div class="kotakunsur <?php echo e(Obj::warna(3,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>3,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
               <div class="kotakunsur <?php echo e(Obj::warna(4,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>4,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
               <div class="kotakunsur"></div>
            </div>
            <div class="baris">
               <div class="kotakunsur <?php echo e(Obj::warna(11,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>11,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
               <div class="kotakunsur <?php echo e(Obj::warna(12,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>12,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
               <div class="kotakunsur"></div>
            </div>
            <div class="baris">
               <div class="kotakunsur <?php echo e(Obj::warna(19,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>19,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
               <div class="kotakunsur <?php echo e(Obj::warna(20,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>20,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
               <div class="kotakunsur <?php echo e(Obj::warna(21,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>21,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
            </div>
            <div class="baris">
               <div class="kotakunsur <?php echo e(Obj::warna(37,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>37,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
               <div class="kotakunsur <?php echo e(Obj::warna(38,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>38,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
               <div class="kotakunsur <?php echo e(Obj::warna(39,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>39,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
            </div>
            <div class="baris">
               <div class="kotakunsur <?php echo e(Obj::warna(55,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>55,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
               <div class="kotakunsur <?php echo e(Obj::warna(56,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>56,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
               <div class="kotakunsur <?php echo e(Obj::warna(57,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>57,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
            </div>
            <div class="baris">
               <div class="kotakunsur <?php echo e(Obj::warna(87,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>87,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
               <div class="kotakunsur <?php echo e(Obj::warna(88,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>88,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
               <div class="kotakunsur <?php echo e(Obj::warna(89,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>89,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
            </div>
        </div>
        <div class="kol2">
                <!-- Baris 1 -->
               <div class="baris">
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(2,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>2,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
               </div>
               <!-- Baris 2 -->
               <div class="baris"> 
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(5,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>5,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(6,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>6,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(7,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>7,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(8,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>8,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(9,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>9,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(10,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>10,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
               </div>
               <div class="baris">
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(13,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>13,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(14,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>14,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(15,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>15,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(16,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>16,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(17,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>17,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(18,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>18,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
               </div>
               <div class="baris">
                  <div class="kotakunsur <?php echo e(Obj::warna(22,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>22,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(23,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>23,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(24,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>24,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(25,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>25,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(26,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>26,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(27,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>27,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(28,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>28,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(29,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>29,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(30,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>30,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(31,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>31,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(32,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>32,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(33,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>33,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(34,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>34,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(35,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>35,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(36,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>36,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
               </div>
               <div class="baris">
                  <div class="kotakunsur <?php echo e(Obj::warna(40,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>40,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(41,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>41,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(42,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>42,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(43,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>43,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(44,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>44,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(45,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>45,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(46,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>46,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(47,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>47,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(48,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>48,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(49,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>49,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(50,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>50,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(51,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>51,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(52,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>52,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(53,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>53,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(54,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>54,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
               </div>
               <div class="baris">
                  <div class="kotakunsur <?php echo e(Obj::warna(72,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>72,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(73,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>73,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(74,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>74,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(75,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>75,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(76,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>76,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(77,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>77,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(78,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>78,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(79,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>79,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(80,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>80,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(81,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>81,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(82,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>82,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(83,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>83,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(84,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>84,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(85,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>85,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(86,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>86,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
               </div>
               <div class="baris">
                  <div class="kotakunsur <?php echo e(Obj::warna(104,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>104,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(105,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>105,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(106,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>106,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(107,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>107,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(108,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>108,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(109,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>109,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(110,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>110,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(111,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>111,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(112,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>112,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(113,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>113,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(114,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>114,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(115,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>115,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(116,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>116,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(117,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>117,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(118,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>118,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
               </div>
        </div>
        <div class="kol3">
        <div class="baris">
                  <div class="kotakunsur <?php echo e(Obj::warna(58,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>58,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(59,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>59,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(60,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>60,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(61,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>61,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(62,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>62,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(63,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>63,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(64,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>64,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(65,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>65,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(66,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>66,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(67,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>67,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(68,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>68,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(69,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>69,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(70,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>70,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(71,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>71,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur"></div>
               </div>
        <div class="baris">
                  <div class="kotakunsur <?php echo e(Obj::warna(90,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>90,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(91,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>91,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(92,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>92,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(93,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>93,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(94,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>94,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(95,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>95,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(96,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>96,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(97,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>97,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(98,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>98,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(99,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>99,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(100,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>100,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(101,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>101,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(102,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>102,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur <?php echo e(Obj::warna(103,$unsur)->namakelas); ?>"><?php echo $__env->make('parts.unsur',['nomor'=>103,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                  <div class="kotakunsur"></div>
               </div>
        </div>
    </div>
    <div class='boxlegend'>
     <div class='kolom'>
        <div class='listlegend color1'>Logam Alkali</div>
        <div class='listlegend color2'>Semimetal</div>
        <div class='listlegend color3'>Aktinids</div>
     </div>
     <div class='kolom'>
        <div class='listlegend color4'>Logam Alkali Tanah</div>
        <div class='listlegend color5'>Non-logam Reaktif</div>
        <div class='listlegend color6'>Properti Tidak Teridentifikasi</div>
     </div>
     <div class='kolom'>
        <div class='listlegend color7'>Metal Transisi</div>
        <div class='listlegend color8'>Gas Mulia</div>
     </div>
     <div class='kolom'>
        <div class='listlegend color9'>Logam Post Transisi</div>
        <div class='listlegend color10'>Lantanida</div>
     </div>
    </div>
</div>

</div>
<?php echo $__env->make('halaman.modal.popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('css/utama.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('js/halaman/utama.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\periodic\resources\views/halaman/utama.blade.php ENDPATH**/ ?>