

<?php $__env->startSection('content'); ?>
<div class="kotak">
<div class="kolomkiri">
    <h3>Media</h3>
    <div class="box">
        <div class="kol1">
            <div class="baris">
               <div class="kotakunsur nonlogam">
                  <?php echo $__env->make('parts.unsur',['nomor'=>1,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
               </div>
               <div class="kotakunsur"></div>
               <div class="kotakunsur"></div>
            </div>
            <div class="baris">
               <div class="kotakunsur"><?php echo $__env->make('parts.unsur',['nomor'=>3,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
               <div class="kotakunsur"><?php echo $__env->make('parts.unsur',['nomor'=>4,'unsur'=>$unsur], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
               <div class="kotakunsur"></div>
            </div>
            <div class="baris">
               <div class="kotakunsur"></div>
               <div class="kotakunsur"></div>
               <div class="kotakunsur"></div>
            </div>
            <div class="baris">
               <div class="kotakunsur"></div>
               <div class="kotakunsur"></div>
               <div class="kotakunsur"></div>
            </div>
            <div class="baris">
               <div class="kotakunsur"></div>
               <div class="kotakunsur"></div>
               <div class="kotakunsur"></div>
            </div>
            <div class="baris">
               <div class="kotakunsur"></div>
               <div class="kotakunsur"></div>
               <div class="kotakunsur"></div>
            </div>
            <div class="baris">
               <div class="kotakunsur"></div>
               <div class="kotakunsur"></div>
               <div class="kotakunsur"></div>
            </div>
        </div>
        <div class="kol2">
               <div class="baris">
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
               </div>
               <div class="baris">
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur nonlogam"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
               </div>
               <div class="baris">
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
               </div>
               <div class="baris">
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
               </div>
               <div class="baris">
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
               </div>
               <div class="baris">
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
               </div>
               <div class="baris">
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
                  <div class="kotakunsur"></div>
               </div>
        </div>
        <div class="kol3">
        <div class="baris">
                     <div class="kotakunsur"></div>
                     <div class="kotakunsur"></div>
                     <div class="kotakunsur"></div>
               </div>
        <div class="baris">
                     <div class="kotakunsur"></div>
                     <div class="kotakunsur"></div>
                     <div class="kotakunsur"></div>
               </div>
        </div>
    </div>
    <div class='boxlegend'>
     <div class='kolom'>
        <div class='listlegend color1'>Logam Alkali</div>
        <div class='listlegend color2'>Semimetal</div>
        <div class='listlegend color3'>Aktinids</div>
     </div>
     <div class='kolom'>
        <div class='listlegend color4'>Logam Alkali Tanah</div>
        <div class='listlegend color5'>Non-logam Reaktif</div>
        <div class='listlegend color6'>Properti Tidak Teridentifikasi</div>
     </div>
     <div class='kolom'>
        <div class='listlegend color7'>Metal Transisi</div>
        <div class='listlegend color8'>Gas Mulia</div>
     </div>
     <div class='kolom'>
        <div class='listlegend color9'>Logam Post Transisi</div>
        <div class='listlegend color10'>Lantanida</div>
     </div>
    </div>
</div>
<div class="kolomkanan">
   <h3>Informasi</h3>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('css/utama.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\periodic\resources\views/halaman/utama.blade.php ENDPATH**/ ?>