

<?php $__env->startSection('content'); ?>
<div class="kotak">
<div class="kolomkiri">
    <h3>Pilih Unsur</h3>
</div>
<div class="kolomkanan">
  <h3>Turunan Unsur</h3>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\periodic\resources\views/halaman/gabung.blade.php ENDPATH**/ ?>