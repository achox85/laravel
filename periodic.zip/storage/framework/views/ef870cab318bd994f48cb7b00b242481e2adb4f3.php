<div class="modal fade" id="mdlProfileCenter" tabindex="-1" role="dialog" aria-labelledby="mdlProfileCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-body">
        <div class="text-center">
            <div class="thumb-photo">
                <div class="wrp"><img src="<?php echo e(asset('gambar/foto.jpg')); ?>"/></div>
            </div>
         <h1>Andi Jelita Vidia Septriasa</h1>
         <h4><?php echo e(Config('app.kelas')); ?></h4>
         <h4><?php echo e(Config('app.nisn')); ?></h4>
        </div>
      </div>
    </div>
  </div>
</div><?php /**PATH D:\laragon\www\periodic\resources\views/parts/profile.blade.php ENDPATH**/ ?>