<!-- Modal -->
<div class="modal fade" id="mdlpilih" tabindex="-1" role="dialog" aria-labelledby="mdlpilihLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Pilih Unsur</h5>
        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <select class="form-select" id="cbunsur">
          <?php if(count($unsur)): ?>
            <?php $__currentLoopData = $unsur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$un): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value='<?php echo e($un->no); ?>' data-code='<?php echo e($un->code); ?>' data-nama='<?php echo e($un->nama); ?>' jenis='<?php echo e($un->namajenis); ?>' kelas='<?php echo e($un->namakelas); ?>'>
              <?php echo e($un->code.' | '.$un->nama); ?>

            </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        </select>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
        <button id="btnpilih" type="button" class="btn btn-primary">Pilih</button>
      </div>
    </div>
  </div>
</div><?php /**PATH D:\laragon\www\periodic\resources\views/halaman/modal/selector.blade.php ENDPATH**/ ?>