<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [App\Http\Controllers\Periodik::class, 'coba'])->name('halaman-utama');
Route::get('/gabung',[App\Http\Controllers\Gabung::class, 'index'])->name('halaman-gabung');

Route::post('/sugesti',[App\Http\Controllers\Gabung::class, 'sugesti']);
Route::post('/load/senyawa',[App\Http\Controllers\Gabung::class, 'senyawa']);

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
